package com.msn.cfaaraujo.salaobelezaapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.os.bundleOf
import kotlinx.android.synthetic.main.login.*

class MainActivity : DebugActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        imageView2.setImageResource(R.drawable.imagem_login)
        mensagem_login.setText(R.string.str_login)

        // evento no botao de login forma 1
        //  botao_login.setOnClickListener{
        //  val valorUsuario = campo_usuario.text.toString()
        //  val valorSenha = campo_senha.text.toString()
        //  Toast.makeText(this, "$valorUsuario: $valorSenha", Toast.LENGTH_LONG).show()
        //  }


        // evento no botao de login forma 2
        botao_login.setOnClickListener { onClickLogin() }
    }
        fun onClickLogin() {
            val valorUsuario = campo_usuario.text.toString()
            val valorSenha = campo_senha.text.toString()
            // Toast.makeText(this, "$valorUsuario: $valorSenha", Toast.LENGTH_LONG).show()

            // criar intent
            intent = Intent(this, TelaInicialActivity::class.java)

            // colocar parametros (opcional)
            val params = Bundle()
            params.putString("nome", valorUsuario)
            intent.putExtras(params)

            // enviar parametros simplificados
            intent.putExtra("numero", 10)

            // fazer chamada
            // startActivity(intent)

            // fazer a chamada esperando resultado
            startActivityForResult(intent, 1)

        }


        override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
            super.onActivityResult(requestCode, resultCode, data)
            if (requestCode == 1) {
                val result = data?.getStringExtra("result")
                Toast.makeText("$result", Toast.LENGTH_LONG).show()
        }
    }
}

